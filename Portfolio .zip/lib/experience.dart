import 'package:flutter/material.dart';

class Experience extends StatefulWidget {
  const Experience({super.key});

  @override
  State<Experience> createState() => _ExperienceState();
}

class _ExperienceState extends State<Experience> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Experience'),
        backgroundColor: Colors.brown[400],
    ),
    backgroundColor: Colors.brown[200],
    body: Padding(
      padding: const EdgeInsets.all(10.0),
      child: Card(
        elevation: 20,
        child:Container(
          width: 400,
          height:460,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
          ),
          child:  const SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, 
              children: [
              Padding(
                padding:  EdgeInsets.all(8.0),
                child:  Text(
                    ' - Responsive Web Design for E-Commerce Platform.',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), 
                  ),
              ),
               
                Padding(
                  padding:  EdgeInsets.all(8.0),
                  child: Text(
            'This project focuses on creating a visually appealing and user-friendly interface that adapts seamlessly to various screen sizes, ensuring an optimal shopping experience for users on all devices.',
            style: TextStyle(fontSize: 14), ),
                ),
                
                Padding(
                  padding:  EdgeInsets.all(8.0),
                  child: Text(
            ' - Development of a Single Page Application.',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), 
                  ),
                ),
                
                Padding(
                  padding:  EdgeInsets.all(8.0),
                  child: Text(
            ' - We are building a dynamic single-page application that enhances performance and provides a smooth user experience by loading content asynchronously without refreshing the page.',
            style: TextStyle(fontSize: 14), 
                  ),
                ),
                
                 Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
            ' - Accessibility Improvements for a Corporate Website.',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
               Padding(
                  padding: EdgeInsets.all(8.0),
                  child:Text(
            'Our goal is to ensure that the corporate website is accessible to all users, including those with disabilities, by implementing best practices in web accessibility and compliance with WCAG standards.',
            style: TextStyle(fontSize: 14), 
                  ),
                ),
              ],
            ),
          )
          
        ),
      ),
    ),
    );
  }
}