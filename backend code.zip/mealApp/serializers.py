from .models import User,Products,Order,CartItems,MyCart,Review
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
class SignInSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('username','password')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user
    
class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Products
        fields = ('id','name','price','category','user')
        extra_kwargs = {'user': {'read_only': True}}


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ['id', 'user', 'total', 'is_paid', 'order_date', 'is_delivered', 'shipping_address', 'name', 'country']
        read_only_fields = ['id', 'user', 'total', 'is_paid', 'order_date', 'is_delivered']


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        data = super().validate(attrs)
        data['user_id'] = self.user.id 
        return data
    

class CartItemSerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source='product.name', read_only=True)
    price = serializers.DecimalField(source='product.price', max_digits=10, decimal_places=2, read_only=True)
    product_id = serializers.IntegerField(write_only=True)  

    class Meta:
        model = CartItems
        fields = ['id', 'quantity', 'product_name', 'price', 'product_id']



# Cart Serializer
class CartSerializer(serializers.ModelSerializer):
    items = CartItemSerializer(many=True, read_only=True)

    class Meta:
        model = MyCart
        fields = ['id', 'user', 'items']
        extra_kwargs = {'user': {'read_only': True}}

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'is_active']

class ReviewSerializer(serializers.ModelSerializer):

    class Meta:
        model = Review
        fields = ['id', 'product', 'rating', 'comment', 'created_at']
        read_only_fields = ['id', 'created_at']

