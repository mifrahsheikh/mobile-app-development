from . import views
from django.urls import path,include
from .views import CustomTokenObtainPairView
urlpatterns=[
    path('all-products/',views.ProductView.as_view(),name='list'),
    path('create-products/',views.ProductCreateView.as_view(),name='create-products'),
    path('retrieve-products/',views.ProductRetriveView.as_view(),name='retrieve'),
    path('update-product/<int:pk>/', views.ProductUpdateView.as_view(), name='product-update'),
    path('delete-product/<int:pk>/', views.ProductDeleteView.as_view(), name='product-delete'),
    
    path('order/', views.UserOrderListView.as_view(), name='order-list'),
    path('create-order/', views.CreateOrderView.as_view(), name='create-order'),
    path('order/<int:pk>/', views.OrderDetailView.as_view(),name='order-details'),
    path('delete/',views.DeleteView.as_view(),name='delete'),
    path('users/', views.UserListView.as_view(), name='user-list'),
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('cart/', views.CartView.as_view(), name='cart'),
    path('cart/add/', views.CartItemView.as_view(), name='add_to_cart'),
    path('all-products/<int:pk>/', views.OrderDetailView.as_view(),name='order-details'),
    path('all-products/<int:product_id>/reviews/', views.ProductReviewsView.as_view(), name='product-reviews'),
    path('all-products/<int:product_id>/reviews/add/', views.AddReviewView.as_view(), name='add-review'),
    path('cart/remove/<int:pk>/', views.RemoveDeleteView.as_view(), name='remove_from_cart'),
    # path('checkout/', views.CheckoutView.as_view(), name='checkout'),
]