from django.shortcuts import render
from .models import User,Products,Order,MyCart,CartItems,Review
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from .serializers import ProductSerializer, SignInSerializer,OrderSerializer,UserSerializer,CartItemSerializer,serializers,CartSerializer,ReviewSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
from .serializers import CustomTokenObtainPairSerializer
from rest_framework.exceptions import NotAuthenticated
from rest_framework.exceptions import ValidationError
from rest_framework.response import Response
from rest_framework import status
# Create your views here.
class UserListView(generics.ListAPIView):
    
    serializer_class = UserSerializer 
    permission_class=[IsAuthenticated]
    def get_queryset(self):
        queryset = User.objects.all().exclude(username='admin1')
        return queryset
class SignUpView(generics.CreateAPIView):
    queryset=User.objects.all()
    serializer_class=SignInSerializer

class ProductView(generics.ListAPIView ):
    queryset=Products.objects.all()
    serializer_class=ProductSerializer
    # permission_classes=[IsAuthenticated]
    # def get_queryset(self):
    #     return Order.objects.filter(user=self.request.user)
    
class ProductCreateView(generics.CreateAPIView):
    serializer_class = ProductSerializer
    # queryset=Products.objects.all()
    permission_classes = [IsAuthenticated]
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class ProductRetriveView(generics.RetrieveAPIView):
    queryset=Products.objects.all()
    serializer_class=ProductSerializer

class ProductUpdateView(generics.UpdateAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.get_queryset().get(pk=self.kwargs['pk'])

class ProductDeleteView(generics.DestroyAPIView):
    queryset = Products.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.get_queryset().get(pk=self.kwargs['pk'])
# user 1

class UserOrderListView(generics.ListAPIView):
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Order.objects.filter(user=self.request.user)


class CreateOrderView(generics.CreateAPIView):
    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request, *args, **kwargs):
        user = request.user
        cart_items = user.cart.items.all()

        if not cart_items.exists():
            return Response({"error": "Cart is empty."}, status=status.HTTP_400_BAD_REQUEST)

        total = sum(item.product.price * item.quantity for item in cart_items)

        order = Order.objects.create(
            user=user,
            total=total,
            shipping_address=request.data.get('shipping_address'),
            name=request.data.get('name'),
            country=request.data.get('country'),
        )

        for item in cart_items:
            item.order = order
            item.save()

        cart_items.delete()


        return Response(OrderSerializer(order).data, status=status.HTTP_201_CREATED)


class OrderDetailView(generics.RetrieveAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer 

class DeleteView(generics.DestroyAPIView):
    queryset=Order.objects.all()
    serializer_class=OrderSerializer

class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer

class CartView(generics.RetrieveAPIView):
    serializer_class = CartSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        cart, _ = MyCart.objects.get_or_create(user=self.request.user)
        return cart


class CartItemView(generics.CreateAPIView):
    serializer_class = CartItemSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        cart, _ = MyCart.objects.get_or_create(user=self.request.user) 
        product_id = self.request.data.get('product_id')
        if not product_id:
            raise serializers.ValidationError("Product ID is required.")

        try:
            product = Products.objects.get(id=product_id)
        except Products.DoesNotExist:
            raise serializers.ValidationError({"error": "Invalid product ID."})

        serializer.save(cart=cart, product=product)
class RemoveDeleteView(generics.DestroyAPIView):
    queryset = CartItems.objects.all()
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.get_queryset().get(pk=self.kwargs['pk'])
class ProductReviewsView(generics.ListAPIView):
    serializer_class = ReviewSerializer

    def get_queryset(self):
        product_id = self.kwargs['product_id']
        return Review.objects.filter(product_id=product_id).order_by('created_at')
class AddReviewView(generics.CreateAPIView):
    queryset = Review.objects.all()  
    serializer_class = ReviewSerializer

