import 'package:flutter/material.dart';
import 'package:flutter_full_stack/createproduct.dart';
import 'package:flutter_full_stack/editscreen.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'userscreen.dart';

class ProductScreen extends StatelessWidget {
  const ProductScreen({super.key});

  Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }

  Future<List<dynamic>> fetchProducts() async {
    const String url = 'http://127.0.0.1:8000/api/all-products/';

    try {
      final token = await _getToken();
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to load products. Status: ${response.statusCode}');
      }
    } catch (error) {
      throw Exception('Error fetching products: $error');
    }
  }

  Future<void> deleteProduct(int productId) async {
    final String url = 'http://127.0.0.1:8000/api/delete-product/$productId/';

    try {
      final token = await _getToken();
      final response = await http.delete(Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 204) {
        print("Product deleted successfully");
      } else {
        throw Exception('Failed to delete product. Status: ${response.statusCode}');
      }
    } catch (error) {
      throw Exception('Error deleting product: $error');
    }
  }
 Future<void> logout(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear(); 

    Navigator.pushReplacementNamed(context, '/sign-in');
  }
  @override
 Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Products'),
        backgroundColor: Colors.brown,
      
      ),
      body: FutureBuilder<List<dynamic>>(
        future: fetchProducts(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No products found.'));
          }

          final products = snapshot.data!;
          return ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              return Card(
              margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
              child: ListTile(
              title: Text(product['name']),
              subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Text('Price: \$${product['price']}'),
              Text('Category: ${product['category']}'),
],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                  IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(
                  builder: (context) => EditProductScreen(product: product),
                  ),
                  );
                },
               ),
                      IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () async {
                          await deleteProduct(product['id']);
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddProductScreen()),
          );
        },
        child: const Icon(Icons.add),
      ),
      
        bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const UserScreen()),
                );
              },
              child: const Text(
              'View Users',
                style: TextStyle(fontSize: 16, color: Color.fromARGB(255, 15, 15, 15)),
              ),
            ),
              ElevatedButton(
              onPressed: () => logout(context),
              child: const Text(
                'Logout',
                style: TextStyle(fontSize: 16, color: Color.fromARGB(255, 15, 15, 15)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
