import 'package:flutter/material.dart';
import 'package:flutter_full_stack/myprofile.dart';
import 'package:flutter_full_stack/newcart.dart';
import 'package:flutter_full_stack/orderdetail.dart';
import 'package:flutter_full_stack/product.dart';
import 'package:flutter_full_stack/signin.dart';
import 'package:flutter_full_stack/userhome.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  Future<String?> _getUserId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_id'); 
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
       initialRoute: '/sign-in',
      routes: {
        '/sign-in': (context) => const SignIn(),
        '/home': (context) => const Userhome(),
        '/profile': (context) => const ProfileScreen(),
        '/detail': (context) => const OrderDetailScreen(orderId: 0),
        '/product': (context) => const ProductScreen(),
        '/cart':(context)=>const CartScreen(),
      
      },
    );
  }
}

class ProtectedPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    );
  }
}
