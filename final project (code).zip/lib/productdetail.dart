import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class ProductDetail extends StatefulWidget {
  final int productId;

  const ProductDetail({Key? key, required this.productId}) : super(key: key);

  @override
  _ProductDetailState createState() => _ProductDetailState();
}

class _ProductDetailState extends State<ProductDetail> {
   Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('token');
  }
  Map<String, dynamic>? productDetails;
  List<dynamic> reviews = [];
  bool isLoading = true;
  
  double? userRating;
  TextEditingController reviewController = TextEditingController();

 Future<void> fetchProductDetails() async {
    final productUrl = 'http://127.0.0.1:8000/api/all-products/${widget.productId}/';
    final reviewsUrl = 'http://127.0.0.1:8000/api/all-products/${widget.productId}/reviews/';
    final token = await _getToken();

    try {
        final productResponse = await http.get(Uri.parse(productUrl),
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token',
            },
        );
        final reviewsResponse = await http.get(Uri.parse(reviewsUrl),
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token',
            },
        );

        if (productResponse.statusCode == 200 && reviewsResponse.statusCode == 200) {
            setState(() {
                productDetails = jsonDecode(productResponse.body);
                reviews = jsonDecode(reviewsResponse.body);
                isLoading = false;
            });
        } else {
            throw Exception('Failed to fetch product details or reviews');
        }
    } catch (error) {
        setState(() {
            isLoading = false;
        });
    }
}


 Future<void> submitReview(double rating, String comment) async {
    final url = 'http://127.0.0.1:8000/api/all-products/${widget.productId}/reviews/add/';
    final token = await _getToken();
    try {
     final response = await http.post(
            Uri.parse(url),
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $token',
            },
            body: jsonEncode({
                'rating': rating,
                'comment': comment,
                'product': widget.productId,
            }));

      if (response.statusCode == 201) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Review submitted!')),
        );
        fetchProductDetails(); 
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${response.body}')),
        );
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $error')),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    fetchProductDetails();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (productDetails == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Product Details')),
        body: const Center(child: Text('No product details available.')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(productDetails!['name'] ?? 'Unknown Product')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
           
            const SizedBox(height: 16),
            const Text('Leave a Review:'),
            Row(
              children: List.generate(5, (index) {
                return IconButton(
                  icon: Icon(
                    userRating != null && userRating! > index
                        ? Icons.star
                        : Icons.star_border,
                    color: Colors.amber,
                  ),
                  onPressed: () {
                    setState(() {
                      userRating = index + 1.0;
                    });
                  },
                );
              }),
            ),
            TextField(
              controller: reviewController,
              decoration: const InputDecoration(labelText: 'Write your review'),
            ),
            ElevatedButton(
              onPressed: userRating == null
                  ? null
                  : () {
                      submitReview(userRating!, reviewController.text);
                      reviewController.clear();
                      setState(() {
                        userRating = null;
                      });
                    },
              child: const Text('Submit Review'),
            ),
            const SizedBox(height: 16),
            const Text('Reviews:', style: TextStyle(fontSize: 18)),
            Expanded(
              child: ListView.builder(
                itemCount: reviews.length,
                itemBuilder: (context, index) {
                  final review = reviews[index];
                  return ListTile(
                    title: Text('Rating: ${review['rating']}'),
                    subtitle: Text(review['comment'] ?? 'No comment provided'),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
