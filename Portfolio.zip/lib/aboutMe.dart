import 'package:flutter/material.dart';

class Aboutme extends StatefulWidget {
  const Aboutme({super.key});

  @override
  State<Aboutme> createState() => _AboutmeState();
}

class _AboutmeState extends State<Aboutme> {

  var textdata = ['Graduation', 'Intermediate', 'Profession', 'Date of Birth','Education'];
  var moredata = ['Bachelors Of Science in Information Engineering Technology (BSIET)','ICS (2019-2021)','IT Engineer','17-05-2004','Higher Education' ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
      title: const Text('About Me'),
      backgroundColor: Colors.brown[400],
      ),
      backgroundColor: Colors.brown[200],
      body: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
      const Padding(
      padding:  EdgeInsets.all(10.0),
      child: Text(
      'Education',
      style:  TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
      ),
      ),
      Expanded(
      child: ListView.separated(
      itemBuilder: (context, index) {
      return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
      Text(
      textdata[index],
      style: const TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.bold,
      color: Colors.brown,
      ),
      ),
      const SizedBox(height: 8),
      Text(
      moredata[index],
      style: const TextStyle(
      fontSize: 16,
      color: Colors.black87,
   ),
  ),
  ],
 ),
    );},
      separatorBuilder: (context, index) {
      return const Divider(height: 10,color: Colors.white,
    );
},
      itemCount: textdata.length,
),
),
],
),
);
  }
}
