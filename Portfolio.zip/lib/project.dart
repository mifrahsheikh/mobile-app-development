import 'package:flutter/material.dart';
import 'package:flutter_application_1/experience.dart';

class Project extends StatefulWidget {
  const Project({super.key});

  @override
  State<Project> createState() => _ProjectState();
}

class _ProjectState extends State<Project> {

  final  title = ["Todo App","Weather App","Expense Tracker App"];
  final  description = [
    "A todo app is a digital application that allows users to create and manage lists of tasks they need to complete, essentially acting as a virtual to-do list where you can add new tasks",
    "A weather app a mobile application on your phone or computer that provides information about the current and forecasted weather conditions for a specific location.",
    "An expense tracker app is a digital tool that allows users to record and categorize their spending, providing a clear overview of where their money is going so they can identify patterns.",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Projects and Experiences",style: TextStyle(fontWeight: FontWeight.bold),),
        backgroundColor: Colors.brown[400],),
      backgroundColor: Colors.brown[200],

      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: title.length, 
              itemBuilder: (context, index) {
                return 
                  Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Container(
                  height: 200,
                  child: Card(
                  color: Colors.brown[100],
                  elevation: 20,
                  child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                   Text( title[index], 
                   style: const TextStyle(fontSize: 16,
                  fontWeight: FontWeight.bold),
            ),
                  Text(
                  description[index],  
                  style: const TextStyle(fontSize: 14),
            ),   
            ],
            ),
            ),
            ),
            ),
             );
            },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(5.0),
            child: ElevatedButton(
              onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => const Experience()));
            },
            child: Text('Experience')),
          ),
        ],
      ),
);
  }
}
