import 'package:flutter/material.dart';
import 'package:flutter_application_1/aboutMe.dart';
import 'package:flutter_application_1/interest.dart';
import 'package:flutter_application_1/project.dart';
import 'package:flutter_application_1/skills.dart';
import 'package:flutter_application_1/splash.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PORTFOLIO ',
      theme: ThemeData(
        colorSchemeSeed: Colors.brown,
        useMaterial3: true,
      ),
      home:const MyWidget(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}
class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    backgroundColor: Colors.brown[200],
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
        children: [
        const Padding(
        padding:  EdgeInsets.all(18.0),
        child: Text('MIFRAH ANIS',
        style: TextStyle(
        fontSize: 40,
        color: Colors.white,
        fontWeight: FontWeight.bold,
        ),
        ),
        ),
        Container(
          width: 150, 
          height: 150, 
          decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(75), 
          image:const DecorationImage(
          image: AssetImage('assets/images/png1.jpg'),
          
        ),
        ),
        ),
             Padding(
         padding: const EdgeInsets.all(10.0),
         child: Card(
         elevation: 18,
         color: Colors.brown[300],
         shape: RoundedRectangleBorder(
         borderRadius: BorderRadius.circular(10),
        ),
             child: Column(
             children: [
         Container(
             width: 400,
             height: 160,
             child: Padding(
             padding:  const EdgeInsets.all(10.0),
             child:  Container(
             width: 400,
             height: 150,
             decoration: BoxDecoration(
             border: Border.all(
             color: Colors.black,
         ),
         ),
            child: const Padding(
            padding:  EdgeInsets.all(10.0),
            child:  Text('I am a passionate mobile app developer, I build apps that are simple to use, visually appealing, and perform well and  My goal is to deliver high-quality applications that exceed user expectations.', 
            style: TextStyle(fontSize: 15,),
         ),
         ),
         ),
         ),
         ), 
         ],
         ),
         ),
         ),
          const Padding(padding: EdgeInsets.all(9.0)),
             SingleChildScrollView(
        scrollDirection: Axis.horizontal,
         child: Row(
           mainAxisAlignment: MainAxisAlignment.center, 
           crossAxisAlignment: CrossAxisAlignment.center, 
           children: [
           const Padding(padding: EdgeInsets.all(8.0)),
           InkWell(
           onTap: () {
           Navigator.push(
           context,
           MaterialPageRoute(builder: (context) => const SkillsWidget()),
         );
         },
          child: Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
            border: Border.all(color: Colors.white),
            borderRadius: BorderRadius.circular(30),
            color: Colors.white,
         ),
          child: const Center(
            child:  Text('skills',
            style: TextStyle(
            color: Colors.brown,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            ),
            ),
          ),
         ),
         ),
          
          const Padding(padding: EdgeInsets.all(10.0)),
          InkWell(
          onTap: () {
          Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const Project()),
         );
          },
          child: Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
            border: Border.all(color: Colors.white),
            borderRadius: BorderRadius.circular(30),
            color: Colors.white,
         ),
          child: const Center(
            child:  Text('projects',
            textAlign: TextAlign.center, 
            style: TextStyle(
            fontSize: 16,
            color: Colors.brown,
            fontWeight: FontWeight.bold,
            ),
            ),
          ),
         ),
         ),
          const Padding(padding: EdgeInsets.all(10.0)),
          InkWell(
          onTap: () {
          Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const Interests()),
         );
         },
          child: Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
            border: Border.all(color: Colors.white),
            borderRadius: BorderRadius.circular(30),
            color: Colors.white,
         ),
          child: const Center(
            child:  Text('interests', 
            textAlign: TextAlign.center,
            style: TextStyle(
            color: Colors.brown, 
            fontSize: 16,    
            fontWeight: FontWeight.bold,   
             ),
             ),
          ),      
         ),
         ),  
           const Padding(padding: EdgeInsets.all(10.0)),
          InkWell(
          onTap: () {
          Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const Aboutme()),
         );
          },
        
          child: Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
            border: Border.all(color: Colors.white),
            borderRadius: BorderRadius.circular(30),
            color: Colors.white,
         ),
          child: const Center(
            child:  Text('About me',
            textAlign: TextAlign.center, 
            style: TextStyle(
            fontSize: 16,
            color: Colors.brown,
            fontWeight: FontWeight.bold,
            ),
            ),
          ),
         ),
         ),    
         ],
         ),
             ),
          const Padding(padding: EdgeInsets.all(12.0)),
          const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
                  padding: EdgeInsets.all(12.0),
                  child: Icon(Icons.facebook, color: Colors.blue, size: 40),
            ),
            Padding(
                  padding: EdgeInsets.all(12.0),
                  child: Icon(Icons.work, color: Colors.blue, size: 40),
            ),
            Padding(
                  padding: EdgeInsets.all(12.0),
                  child: Icon(Icons.inbox, color: Colors.white, size: 40),
            ),
            Padding(
                  padding: EdgeInsets.all(12.0),
                  child: Icon(Icons.camera, color: Colors.pink, size: 40),
          ),
         ],
         ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
            color: Colors.brown[400],
            borderRadius: BorderRadius.circular(12),
        ),
            child: const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children:  [
            Icon(
            Icons.email,
            color: Colors.white,
            size: 30,
        ),
            Text(
             'Email: mifrahsheikh77@gmail.com',
              style: TextStyle(
              fontSize: 16,
              color: Colors.white,
          ),
          ),
          ],
          ),
          ),
           ),
          ],
          ),
      ),
    );
  }
}          