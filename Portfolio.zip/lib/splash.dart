import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_application_1/main.dart';

class MyWidget extends StatefulWidget {
  const MyWidget({super.key});

  @override
  State<MyWidget> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget> {
  @override
  void initState(){
    Timer(const Duration(seconds: 2),
    ()=>Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>const MyHomePage()),),
    );
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: Colors.brown[200],
body: const Center(
  child: Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      CircularProgressIndicator(
      color: Color.fromARGB(240, 0, 0, 0),
      strokeWidth: 6.0,
 ),
    ],
  ),
),
    );
  }
}