import 'package:flutter/material.dart';

class Interests extends StatefulWidget {
  const Interests({super.key});

  @override
  State<Interests> createState() => _InterestsState();
}

class _InterestsState extends State<Interests> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Interests'),  
        backgroundColor: Colors.brown[400],
        ),
        backgroundColor: Colors.brown[200],
     
          body:  Card(
            color: Colors.brown[200],
            elevation: 20,
          child: Container(
            height: 800,
            child: const SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
              children: [
                Padding(padding: EdgeInsets.all(8.0)),
                Text('Mobile App Development',textAlign: TextAlign.start, style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold, )),
                Padding(padding: EdgeInsets.all(6.0)),
                Text('Mobile app development refers to the process of creating software applications specifically designed to run on mobile devices like smartphones and tablets, involving coding and designing apps'),
                Padding(padding: EdgeInsets.all(11.0)),
                Text('Web Development', style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold)),
                Padding(padding: EdgeInsets.all(6.0)),
                Text('Web development refers to the process of creating websites and web applications using programming languages like HTML'),
                  Padding(padding: EdgeInsets.all(11.0)),
                Text('Machine Learning', style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold)),
                Padding(padding: EdgeInsets.all(6.0)),
                Text('Machine learning is a subset of artificial intelligence that involves the use of algorithms and statistical models'),
                 Padding(padding: EdgeInsets.all(11.0)),
                Text('UI/UX Design', style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold)),
                Padding(padding: EdgeInsets.all(6.0)),
                Text('UI/UX development refers to the process of designing and building digital products, like websites and apps, with a focus on both the visual appearance'),
                  Padding(padding: EdgeInsets.all(11.0)),
                Text('Cloud Computing', style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold)),
                Padding(padding: EdgeInsets.all(6.0)),
                Text('Cloud computing refers to the practice of using a network of remote servers hosted on the internet'),
                  Padding(padding: EdgeInsets.all(11.0)),
                Text('Open Source Contribution', style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold)),
                Padding(padding: EdgeInsets.all(6.0)),
                Text('Open source contribution refers to the process of contributing to open source projects'),
              ],
              ),
            ),
          ),
          ),
        
    );
  }
}