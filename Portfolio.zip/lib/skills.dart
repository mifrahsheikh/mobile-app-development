import 'package:flutter/material.dart';

class SkillsWidget extends StatefulWidget {
  const SkillsWidget({super.key});

  @override
  State<SkillsWidget> createState() => _SkillsWidgetState();
}

class _SkillsWidgetState extends State<SkillsWidget> {
  @override
  Widget build(BuildContext context) {
   double percentage1 = 50.0; 
   double percentage2= 40.0;
   double percentage3= 80.0;
   double contwidth = 400.0; 
  
return Scaffold(
  appBar: AppBar(
    title: const Text("My Skills"),
    backgroundColor: Colors.brown[400],
  ),
  backgroundColor: Colors.brown[200],

  body: Padding(
    padding: const EdgeInsets.all(8.0),
    child: Column(
      children: [
      const Padding(
          padding:  EdgeInsets.all(13.0),
          child:  Align(
            alignment: Alignment.centerLeft,
            child: Text(
            'SKILLS',
            style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            ),
            ),
          ),
),
       const Padding(
          padding:  EdgeInsets.all(13.0),
          child: Text(
          'flutter',
          style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,))),
        Padding(
          padding: const EdgeInsets.all(13.0),
          child: Container(
            width: contwidth,
            height: 10,
            decoration: BoxDecoration(
            border: Border.all(color: const Color.fromARGB(255, 17, 18, 19)),
            borderRadius: BorderRadius.circular(50),
            color: Colors.grey[300],
            ),
            child: Align(
            alignment: Alignment.centerLeft,
            child: Container(
            width: (percentage1 / 100) * contwidth, 
            height: 10,
            decoration: BoxDecoration(
            color: Colors.blue,
            borderRadius: BorderRadius.circular(50),
          ),
          ),
          ),
          ),
        ),
    const  Padding(
          padding:  EdgeInsets.all(15.0),
          child: Text(
          'Dart',
          style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,
            ),
          ),
        ),
    Padding(
      padding: const EdgeInsets.all(13.0),
      child: Container(
            width: contwidth,
            height: 10,
            decoration: BoxDecoration(
            border: Border.all(color: const Color.fromARGB(255, 17, 18, 19)),
            borderRadius: BorderRadius.circular(50),
            color: Colors.grey[300],
            ),
            child: Align(
            alignment: Alignment.centerLeft,
            child: Container(
            width: (percentage2 / 100) * contwidth, 
            height: 10,
            decoration: BoxDecoration(
            color: const Color.fromARGB(255, 137, 86, 213),
            borderRadius: BorderRadius.circular(50),
      ),
       ),
            ),
          ),
    ),
    
    const  Padding(
          padding:  EdgeInsets.all(14.0),
          child: Text(
          'UI/UX Design',
          style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.bold,
  ),
  ),
        ),
        Padding(
          padding: const EdgeInsets.all(13.0),
          child: Container(
            width: contwidth,
            height: 10,
            decoration: BoxDecoration(
            border: Border.all(color: const Color.fromARGB(255, 17, 18, 19)),
            borderRadius: BorderRadius.circular(50),
            color: Colors.grey[300],
            ),
            child: Align(
            alignment: Alignment.centerLeft,
            child: Container(
            width: (percentage3 / 100) * contwidth, 
            height: 10,
            decoration: BoxDecoration(
            color: const Color.fromARGB(255, 104, 57, 117),
            borderRadius: BorderRadius.circular(50),
          ),
          ),
            ),
          ),
        ),
      ],
    ),
  ),
);
  }}